package com.orderservice.sprint4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Sprint4ApplicationTests {

	@Test
	void contextLoads() {
	}

}
