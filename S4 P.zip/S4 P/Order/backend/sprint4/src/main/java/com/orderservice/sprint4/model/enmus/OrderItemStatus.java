package com.orderservice.sprint4.model.enmus;

public enum OrderItemStatus {
    Pending,
    Ordered,
    Shipped,
    Cancelled,
    Returned,
    Failed
}
