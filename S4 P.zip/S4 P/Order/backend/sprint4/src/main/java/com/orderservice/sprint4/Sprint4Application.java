package com.orderservice.sprint4;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Sprint4Application {

	public static void main(String[] args) {
		SpringApplication.run(Sprint4Application.class, args);
	}

}
