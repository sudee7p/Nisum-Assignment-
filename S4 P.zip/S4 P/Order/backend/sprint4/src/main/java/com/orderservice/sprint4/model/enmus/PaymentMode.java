package com.orderservice.sprint4.model.enmus;

public enum PaymentMode {
    Card,
    Wallet,
    NetBanking,
    UPI,
    EMI,
    COD
}
