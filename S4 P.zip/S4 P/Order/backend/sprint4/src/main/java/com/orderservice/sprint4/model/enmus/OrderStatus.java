package com.orderservice.sprint4.model.enmus;

public enum OrderStatus {
    Pending,
    Ordered,
    Cancelled,
    Failed
}
