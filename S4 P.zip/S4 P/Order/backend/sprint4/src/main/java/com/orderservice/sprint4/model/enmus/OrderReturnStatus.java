package com.orderservice.sprint4.model.enmus;

public enum OrderReturnStatus {
    Requested,
    Approved,
    Rejected,
    Completed
}
